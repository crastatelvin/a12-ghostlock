#!/system/bin/sh
{
  echo "service ran"
  echo "KSU=$KSU KSU_MODULE=$KSU_MODULE KSU_VER=$KSU_VER"
  echo "PATH=$PATH"
  date
} > /data/local/tmp/a12mod_service.txt 2>&1