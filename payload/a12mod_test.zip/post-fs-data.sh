#!/system/bin/sh
echo "post-fs-data ran KSU_MODULE=$KSU_MODULE" > /data/local/tmp/a12mod_postfs.txt 2>&1