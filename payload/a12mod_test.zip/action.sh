#!/system/bin/sh
echo "action ran for $KSU_MODULE"